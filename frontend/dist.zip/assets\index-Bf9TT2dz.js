const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Home-BFUJqUKL.js","assets/rolldown-runtime-CNC7AqOf.js","assets/vendor-CiqqDoek.js","assets/vendor-react-rsXa5AtT.js","assets/vendor-framer-CQB1OUMY.js","assets/programService-C3rIpKn9.js","assets/api-8E9y314O.js","assets/useAuthStore-DQF9gOle.js","assets/FinalCTA-rQCJXeVS.js","assets/EventCard-0gjZoTRM.js","assets/eventService-C863KXcr.js","assets/ProgramCard-D6s_CEYi.js","assets/Badge-DPH3tnbA.js","assets/cn-DU7q2OdH.js","assets/TestimonialCard-CWd7oOFE.js","assets/testimonialService-Dl-v1WiY.js","assets/Accordion-CY8520jE.js","assets/About-BiSxandE.js","assets/SectionHeader-D7Jyhv0V.js","assets/VisionMission-DnocIOCU.js","assets/Campus-Dbe36yb6.js","assets/Programs-Vhj8IXfX.js","assets/ProgramDetails-CX3-On4i.js","assets/Tabs-CPeMbZSf.js","assets/Admissions-BRrB-qyy.js","assets/Select-CQSxpffz.js","assets/Mentors-rodB18nB.js","assets/Events-C-sKtN8K.js","assets/Gallery-b_ruNx35.js","assets/Blog-BtoIkFaC.js","assets/blogService-71_Nj96N.js","assets/BlogDetails-DL2vPKIs.js","assets/Resources-mJ4wEY99.js","assets/Placements-1kyK2g6v.js","assets/Testimonials-AMiVwLFB.js","assets/FreePrograms-CDSdXeKZ.js","assets/ForInstitutions-C9p5WutC.js","assets/Recognitions-BnS6f2NX.js","assets/Contact-BoEFbPLE.js","assets/Textarea-DI6JNVmR.js","assets/Career-CgYDHgAM.js","assets/Support-oTWDrpDC.js","assets/Privacy-DayuVIWL.js","assets/Terms-CvtZDWfJ.js","assets/NotFound-Dz94w6PS.js","assets/JoinUs-Cg51oCZo.js","assets/Login-DQhUhwnm.js","assets/Register-CZPnRvyv.js","assets/ForgotPassword-BoggxTrk.js","assets/ResetPassword-2X-t3TCL.js","assets/StudentDashboard-DWgpDYtC.js","assets/NotificationDropdown-C3RSiFKq.js","assets/admissionService-BFF0ca88.js","assets/userService-CmBO89Zq.js","assets/FacultyDashboard-D1xGhDPe.js","assets/AdminLayout-DkGjZq0o.js","assets/DashboardHome-Cx0DNd90.js","assets/analyticsService-C1lb36jH.js","assets/ManageStudents-0osIrvVT.js","assets/Pagination-bNPlbxCR.js","assets/Modal-A914zQqf.js","assets/studentService-uGribFJF.js","assets/StudentProfile-XPxjUkM2.js","assets/ManageAdmissions-CJq_Vwjt.js","assets/exportToCSV-CATlQu6q.js","assets/ApplicationDetails-a2vEHjyz.js","assets/ManageInquiries-D-cW3oPO.js","assets/ManagePrograms-DXADxVLv.js","assets/ProgramForm-DifBY6qY.js","assets/ManageMentors-DAhADQ8R.js","assets/mentorService-DeoW8Hht.js","assets/MentorForm-DsLt8EE5.js","assets/ManageEvents-DBrj-jU8.js","assets/EventForm-CoIJ4ZA2.js","assets/ManageWorkshops-BRRvjlVv.js","assets/workshopService-C7fgFQfj.js","assets/WorkshopForm-Bmw6JZb3.js","assets/ManageCourses-DzFSCZYK.js","assets/courseService-BHFo2Dm_.js","assets/CourseForm-UZdl-yvA.js","assets/ManageBlogs-26CeLMMH.js","assets/BlogForm-BZRF0i1K.js","assets/ManageGallery-wfIHbsuG.js","assets/ManageHomepage-DGZcuk_G.js","assets/ManageAbout-BmiJ29Nv.js","assets/ManageSEO-CbLVDurU.js","assets/ManageSettings-BSB6dU8v.js","assets/ManageNotifications-C4YugMH8.js","assets/ManageFAQ-DjPfVmvl.js","assets/ManageNavigation-gJEB3GNG.js","assets/ManageCampus-Dh3BtLnV.js","assets/ManageCareers-BpnVycS4.js","assets/ManageLegal-B2RWdFQJ.js","assets/ManageExitIntent-D4SVAmkV.js","assets/ManageSocialProof-Cu4S1Hqy.js","assets/ManageQuickConnect-DQpkbJ0G.js","assets/ManageTestimonials-CPNALGw2.js","assets/ManageNewsletter-BOeqLFuw.js","assets/CMSLayout-BwGkuzI3.js","assets/PageEditor-M4m9QJYe.js","assets/AnalyticsDashboard-SQHsjvRh.js","assets/FacultyAnalytics-CIXj5573.js","assets/ManagementAnalytics-BewjT71F.js","assets/AuditLogConsole-CVv08mLk.js","assets/ManageMediaLibrary-CMlUsHCu.js","assets/ManageCMSPages-DWC7mOFZ.js","assets/ManageRolesPermissions-_4FO60L8.js","assets/ManageLeadsCRM-DTOeAqq3.js","assets/ManageEmailCampaigns-DYHqFpAg.js","assets/ManageBackups-C0ihYw5N.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-CNC7AqOf.js";import{J as t,L as n,Q as r,R as i,V as a,Y as o,c as s,d as c,f as l,l as u,s as d,t as f}from"./vendor-CiqqDoek.js";import{F as p,G as m,Gt as h,Ht as g,J as _,M as ee,Q as te,Tn as ne,Ut as re,W as ie,X as ae,Y as oe,_n as v,bn as se,dt as y,et as ce,f as le,fn as b,gn as x,hn as ue,in as de,kt as fe,l as pe,ln as me,lt as he,mn as ge,o as S,pn as _e,un as ve,vn as ye,wn as C,wt as be,xn as w,yn as T,zt as xe}from"./vendor-react-rsXa5AtT.js";import{n as E,r as Se,t as D}from"./vendor-framer-CQB1OUMY.js";import{t as O}from"./cn-DU7q2OdH.js";import{t as k}from"./useAuthStore-DQF9gOle.js";import{t as A}from"./api-8E9y314O.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var Ce=e(ne(),1),j=e(r(),1),M=Se(),N=j.forwardRef(({className:e,variant:t=`primary`,size:n=`md`,isLoading:r=!1,children:i,leftIcon:a,rightIcon:o,as:s=`button`,fullWidth:c=!1,...l},u)=>(0,M.jsx)(s===`button`?D.button:D(s),{whileTap:{scale:.98},whileHover:{y:-1},transition:{type:`spring`,stiffness:400,damping:25},ref:u,className:O(`inline-flex items-center justify-center font-semibold transition-all duration-250 ease-out select-none active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none disabled:shadow-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 focus-visible:ring-offset-2 shrink-0`,{primary:`bg-[#1b321e] hover:bg-[#254228] text-amber-300 border border-amber-400/40 shadow-sm hover:shadow-md hover:shadow-black/15 font-bold`,gold:`bg-gradient-to-r from-[#d49e35] to-[#c28e2b] hover:from-[#c28e2b] hover:to-[#b07e21] text-slate-950 border border-amber-300/40 shadow-sm hover:shadow-md font-bold`,secondary:`bg-white/90 dark:bg-[#132214] backdrop-blur-md text-gray-800 dark:text-emerald-100 border border-gray-200/90 dark:border-amber-400/30 hover:border-amber-400/60 hover:bg-amber-50/40 dark:hover:bg-[#1c3320] hover:text-amber-700 dark:hover:text-amber-300 shadow-xs`,outline:`border border-amber-400/40 bg-transparent text-amber-300 hover:bg-[#1f3521] hover:text-white shadow-xs font-semibold`,ghost:`bg-transparent text-gray-700 dark:text-emerald-100 hover:bg-emerald-950/30 hover:text-amber-300`,text:`bg-transparent text-amber-500 dark:text-amber-400 hover:text-amber-600 dark:hover:text-amber-300 p-0 h-auto font-semibold hover:underline`,dark:`bg-gray-900 hover:bg-black text-white dark:bg-[#101b11] dark:hover:bg-[#162617] shadow-sm border border-emerald-900/60`,danger:`bg-rose-700 hover:bg-rose-800 text-white shadow-sm border border-rose-600/40`,success:`bg-emerald-700 hover:bg-emerald-800 text-white shadow-sm border border-emerald-600/40`,warning:`bg-amber-600 hover:bg-amber-700 text-white shadow-sm border border-amber-500/40`,white:`bg-white dark:bg-[#132214] text-gray-900 dark:text-amber-300 border border-gray-200 dark:border-amber-400/30 hover:border-amber-400 shadow-xs`,"outline-white":`border border-white/70 bg-white/10 backdrop-blur-md text-white hover:bg-white/20 shadow-xs font-semibold`}[t],{xs:`h-8 px-3 text-xs rounded-lg gap-1.5 min-h-[32px]`,sm:`h-9 px-3.5 text-xs rounded-xl gap-1.5 min-h-[36px]`,md:`h-11 px-5 text-sm rounded-xl gap-2 min-h-[44px]`,lg:`h-12 px-6 text-sm sm:text-base rounded-xl gap-2.5 min-h-[48px]`,xl:`h-14 px-8 text-base sm:text-lg rounded-2xl gap-3 min-h-[52px]`,icon:`h-11 w-11 p-0 rounded-xl justify-center min-h-[44px] min-w-[44px]`,"icon-sm":`h-9 w-9 p-0 rounded-lg justify-center min-h-[36px] min-w-[36px]`}[n],c&&`w-full`,e),disabled:r||(s===`button`?l.disabled:void 0),...l,children:r?(0,M.jsx)(te,{className:`h-4 w-4 animate-spin shrink-0`}):(0,M.jsxs)(M.Fragment,{children:[a&&(0,M.jsx)(`span`,{className:`inline-flex items-center shrink-0`,children:a}),i&&(0,M.jsx)(`span`,{children:i}),o&&(0,M.jsx)(`span`,{className:`inline-flex items-center shrink-0`,children:o})]})}));N.displayName=`Button`;var we=class extends j.Component{constructor(e){super(e),this.state={hasError:!1,error:null}}static getDerivedStateFromError(e){return{hasError:!0,error:e}}componentDidCatch(e,t){console.error(`ErrorBoundary caught an unhandled error:`,e,t)}handleReload=()=>{this.setState({hasError:!1,error:null}),window.location.reload()};render(){return this.state.hasError?(0,M.jsx)(`div`,{className:`min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950 px-4 select-none`,children:(0,M.jsxs)(`div`,{className:`max-w-md w-full text-center bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-8 shadow-2xl`,children:[(0,M.jsx)(`div`,{className:`inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 dark:bg-red-950/50 text-red-600 dark:text-red-400 mb-6 border border-red-200 dark:border-red-800/60`,children:(0,M.jsx)(g,{size:32})}),(0,M.jsx)(`h1`,{className:`text-2xl font-serif font-bold text-gray-900 dark:text-white mb-2`,children:`Something went wrong`}),(0,M.jsx)(`p`,{className:`text-sm text-gray-600 dark:text-gray-300 mb-4 leading-relaxed`,children:`We encountered an unexpected rendering error on this section.`}),this.state.error&&(0,M.jsx)(`div`,{className:`mb-6 p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/40 text-xs font-mono text-red-700 dark:text-red-300 text-left overflow-x-auto max-h-28`,children:this.state.error.toString()}),(0,M.jsxs)(`div`,{className:`flex flex-col sm:flex-row items-center justify-center gap-3`,children:[(0,M.jsxs)(N,{onClick:this.handleReload,variant:`primary`,className:`w-full sm:w-auto flex items-center justify-center gap-2 font-bold text-xs shadow-md`,children:[(0,M.jsx)(ee,{size:16}),`Refresh Page`]}),(0,M.jsx)(x,{to:`/`,className:`w-full sm:w-auto`,onClick:()=>this.setState({hasError:!1}),children:(0,M.jsxs)(N,{variant:`outline`,className:`w-full flex items-center justify-center gap-2 font-bold text-xs`,children:[(0,M.jsx)(y,{size:16}),`Return Home`]})})]})]})}):this.props.children}},Te=`
  *[_type == "siteSettings"][0] {
    siteName,
    siteTagline,
    "logoUrl": logo.asset->url,
    "faviconUrl": favicon.asset->url,
    contactEmail,
    contactPhone,
    whatsappNumber,
    physicalAddress,
    googleMapsUrl,
    googleAnalyticsId,
    socialLinks,
    metaDefaults
  }
`,Ee=`
  *[_type == "heroSlider" && isActive == true] | order(order asc) {
    _id,
    title,
    subtitle,
    description,
    primaryCtaText,
    primaryCtaLink,
    secondaryCtaText,
    secondaryCtaLink,
    "imageUrl": coalesce(bgImage.asset->url, "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=1600"),
    overlayColor
  }
`,De=`
  *[_type == "collaboration"] | order(order asc) {
    _id,
    name,
    category,
    "logoUrl": logo.asset->url,
    websiteUrl
  }
`,Oe=`
  *[_type == "excellenceFactor"] | order(questionNumber asc) {
    _id,
    questionNumber,
    questionTitle,
    questionSubtitle,
    options
  }
`,ke=`
  *[_type == "freeProgram"] {
    _id,
    title,
    "slug": slug.current,
    category,
    duration,
    shortDescription,
    modulesCount,
    enrollLink,
    "imageUrl": coverImage.asset->url
  }
`,Ae=`
  *[_type == "institutionService"] {
    _id,
    title,
    category,
    description,
    keyBenefits,
    icon
  }
`,je=`
  *[_type == "recognition"] {
    _id,
    title,
    issuingBody,
    year,
    description,
    "logoUrl": image.asset->url,
    "imageUrl": image.asset->url
  }
`,Me=`
  *[_type == "homepage"][0] {
    hero {
      title,
      subtitle,
      description,
      primaryCtaText,
      primaryCtaLink,
      secondaryCtaText,
      secondaryCtaLink,
      "imageUrl": heroImage.asset->url,
      videoUrl
    },
    stats,
    whyChooseUs {
      title,
      subtitle,
      features
    },
    impactMetrics,
    finalCta {
      title,
      description,
      buttonText,
      buttonLink
    }
  }
`,Ne=`
  *[_type == "aboutPage"][0] {
    heroTitle,
    "title": coalesce(title, heroTitle),
    heroSubtitle,
    "description": coalesce(description, heroSubtitle),
    storyText,
    "historyText": coalesce(historyText, storyText),
    missionText,
    visionText,
    leadershipMessage,
    founderMessage {
      founderName,
      founderTitle,
      messageText,
      "founderPhotoUrl": founderPhoto.asset->url
    },
    timeline
  }
`,Pe=`
  *[_type == "contactPage"][0] {
    title,
    heroTitle,
    subtitle,
    heroSubtitle,
    email,
    generalEmail,
    supportEmail,
    admissionsEmail,
    phone,
    helplinePhone,
    whatsappSupport,
    address,
    campusAddress,
    workingHours,
    googleMapsEmbedUrl,
    mapEmbedUrl
  }
`,Fe=`
  *[_type == "navigation"][0] {
    logoText,
    "logoImageUrl": logoImage.asset->url,
    menuItems[] {
      label,
      url,
      dropdownItems[] {
        label,
        url,
        description
      }
    },
    headerCta {
      buttonText,
      buttonLink
    }
  }
`,Ie=`
  *[_type == "footer"][0] {
    copyrightText,
    accreditationText,
    quickLinks[] {
      label,
      url
    },
    legalLinks[] {
      label,
      url
    }
  }
`,Le=`
  *[_type == "gallery"] | order(_createdAt desc) {
    _id,
    title,
    category,
    caption,
    "image": coalesce(image.asset->url, "https://via.placeholder.com/600x400"),
    "imageUrl": image.asset->url
  }
`,Re=`
  *[_type == "testimonial"] | order(_createdAt desc) {
    _id,
    name,
    role,
    company,
    program,
    quote,
    "content": quote,
    rating,
    "image": coalesce(avatar.asset->url, "https://via.placeholder.com/100"),
    "avatarUrl": avatar.asset->url
  }
`,ze=`
  *[_type == "event"] | order(date asc) {
    _id,
    title,
    "slug": slug.current,
    category,
    "type": category,
    date,
    time,
    location,
    description,
    registrationLink,
    "image": image.asset->url,
    "imageUrl": image.asset->url
  }
`,Be=`
  *[_type == "blog" && (!defined(status) || status == "published" || status == "Published")] | order(publishedAt desc) {
    _id,
    title,
    "slug": slug.current,
    category,
    excerpt,
    content,
    tags,
    publishedAt,
    "date": publishedAt,
    "author": "Tejas Faculty",
    "coverImage": coalesce(coverImage.asset->url, "https://via.placeholder.com/600x400"),
    "coverImageUrl": coverImage.asset->url
  }
`,Ve=`
  *[_type == "program" && (!defined(status) || status == "published" || status == "Published")] | order(_createdAt desc) {
    _id,
    title,
    "slug": slug.current,
    category,
    duration,
    level,
    fee,
    shortDescription,
    description,
    highlights,
    "image": coalesce(image.asset->url, "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=800"),
    "imageUrl": image.asset->url,
    isFeatured
  }
`,He=`
  *[_type == "mentor"] {
    _id,
    name,
    "slug": slug.current,
    role,
    "title": role,
    department,
    "company": department,
    bio,
    "image": coalesce(image.asset->url, "https://via.placeholder.com/400"),
    "imageUrl": image.asset->url,
    experienceYears,
    linkedInUrl,
    "socialLinks": {
      "linkedin": linkedInUrl
    }
  }
`,Ue=`
  *[_type == "faq"] | order(order asc) {
    _id,
    question,
    answer,
    category,
    order
  }
`,We=`
  *[_type == "popupModal" && isEnabled == true] {
    _id,
    title,
    popupType,
    isEnabled,
    subtitle,
    description,
    "imageUrl": image.asset->url,
    primaryCtaText,
    primaryCtaLink,
    secondaryCtaText,
    secondaryCtaLink,
    displayFrequency,
    targetPages
  }
`,Ge=`
  *[_type == "course"] {
    _id,
    title,
    "slug": slug.current,
    courseCode,
    department,
    credits,
    description,
    instructor,
    "image": coverImage.asset->url,
    "imageUrl": coverImage.asset->url
  }
`,Ke=`
  *[_type == "workshop"] {
    _id,
    title,
    "slug": slug.current,
    date,
    durationHours,
    mode,
    mentorName,
    description,
    "image": coverImage.asset->url,
    "imageUrl": coverImage.asset->url
  }
`,qe=`6nl927hv`,Je=`production`,Ye=`2023-01-01`,P={fetchGroq:async(e,t={})=>{try{let n=encodeURIComponent(e);for(let[e,r]of Object.entries(t))n=n.replace(`$${e}`,`"${r}"`);let r=new Date().getTime(),i=`https://${qe}.api.sanity.io/v${Ye}/data/query/${Je}?query=${n}&_t=${r}`,a=await(await fetch(i,{headers:{},cache:`no-store`})).json();if(a.result)return a.result}catch(e){console.warn(`[SanityService] Direct Sanity fetch error, falling back to Express API:`,e.message)}return null},getSiteSettings:async()=>await P.fetchGroq(Te)||(await A.get(`/cms/site_settings`)).data?.data||{},getHeroSlides:async()=>{let e=await P.fetchGroq(Ee);return e&&e.length>0?e:[{_id:`slide-1`,title:`Developing Leaders, Innovators & Entrepreneurs`,subtitle:`🎓 Admissions Open for Academic Year 2026-27`,description:`Tejas Academy of Excellence cultivates human potential, real-world skills, and character fortitude to accelerate your career.`,primaryCtaText:`Apply for Admissions`,primaryCtaLink:`/admissions`,secondaryCtaText:`Explore Programs`,secondaryCtaLink:`/programs`,imageUrl:`https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&q=80&w=1600`},{_id:`slide-2`,title:`Master Artificial Intelligence & Data Leadership`,subtitle:`🚀 Flagship B.Tech & Postgraduate Programs`,description:`Hands-on learning with neural networks, generative AI, and Cloud architecture co-designed with tech executives.`,primaryCtaText:`Download Curriculum`,primaryCtaLink:`/programs`,secondaryCtaText:`Talk to Advisor`,secondaryCtaLink:`/admissions`,imageUrl:`https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&q=80&w=1600`}]},getCollaborations:async()=>{let e=await P.fetchGroq(De);return e&&e.length>0?e:[{_id:`collab-1`,name:`Microsoft for Startups`,category:`Technology Partner`},{_id:`collab-2`,name:`Amazon Web Services Educate`,category:`Cloud Partner`},{_id:`collab-3`,name:`Google Cloud Academic Program`,category:`AI Partner`},{_id:`collab-4`,name:`National Skill Development Corp`,category:`Government MoU`},{_id:`collab-5`,name:`NASSCOM FutureSkills Prime`,category:`Skill Alliance`}]},getExcellenceFactorSteps:async()=>{let e=await P.fetchGroq(Oe);return e&&e.length>0?e:[{questionNumber:1,questionTitle:`What is your primary professional ambition?`,questionSubtitle:`Select the statement that resonates most with your career goals.`,options:[{label:`Building High-Scale AI & Software Systems`,description:`Deep technical mastery in AI, Cloud, and Software Architecture`,recommendedCategory:`Engineering`,icon:`Cpu`},{label:`Leading Tech Products & Business Ventures`,description:`Product management, executive strategy, and scaling teams`,recommendedCategory:`Management`,icon:`TrendingUp`}]}]},getFreePrograms:async()=>{let e=await P.fetchGroq(ke);return e&&e.length>0?e:[{_id:`fp-1`,title:`Foundations of Generative AI & Prompt Engineering`,category:`AI & Data`,duration:`3 Hours`,shortDescription:`Learn to leverage LLMs, prompt patterns, and generative tools for technical productivity.`,modulesCount:4,enrollLink:`/admissions`}]},getInstitutionServices:async()=>{let e=await P.fetchGroq(Ae);return e&&e.length>0?e:[{_id:`inst-1`,title:`Faculty Development Programs (FDP)`,category:`Faculty Upskilling`,description:`Comprehensive workshops empowering educators with the latest pedagogical tools, AI research methods, and industry case studies.`,keyBenefits:[`AI Curriculum Integration`,`Research Paper Publishing Support`,`Certificates of Mastery`],icon:`BookOpen`}]},getRecognitions:async()=>{let e=await P.fetchGroq(je);return e&&e.length>0?e:[{_id:`rec-1`,title:`Best Academic Innovation Institute 2025`,issuingBody:`National Education Excellence Leadership Awards`,year:`2025`,description:`Recognized for pioneering industry-aligned curriculum and AI research labs.`}]},getHomepage:async()=>await P.fetchGroq(Me)||(await A.get(`/cms/homepage`)).data?.data||null,getAboutPage:async()=>await P.fetchGroq(Ne)||(await A.get(`/cms/about`)).data?.data||null,getContactPage:async()=>await P.fetchGroq(Pe)||(await A.get(`/cms/contact`)).data?.data||null,getNavigation:async()=>await P.fetchGroq(Fe)||(await A.get(`/cms/navigation`)).data?.data||null,getFooter:async()=>await P.fetchGroq(Ie)||(await A.get(`/cms/footer`)).data?.data||null,getGallery:async()=>{let e=await P.fetchGroq(Le);return e&&e.length>0?e:(await A.get(`/gallery`)).data?.data||[]},getTestimonials:async()=>{let e=await P.fetchGroq(Re);return e&&e.length>0?e:(await A.get(`/testimonials`)).data?.data||[]},getEvents:async()=>{let e=await P.fetchGroq(ze);return e&&e.length>0?e:(await A.get(`/events`)).data?.data||[]},getBlogs:async()=>{let e=await P.fetchGroq(Be);return e&&e.length>0?e:(await A.get(`/blogs`)).data?.data||[]},getPrograms:async()=>{let e=await P.fetchGroq(Ve);if(e&&e.length>0)return e;let t=await A.get(`/programs`);return t.data?.data?.programs||t.data?.data||[]},getMentors:async()=>{let e=await P.fetchGroq(He);return e&&e.length>0?e:(await A.get(`/faculty`)).data?.data||[]},getFaqs:async()=>{let e=await P.fetchGroq(Ue);return e&&e.length>0?e:(await A.get(`/cms/global_faqs`)).data?.data||[]},getPopupModals:async()=>{let e=await P.fetchGroq(We);return e&&e.length>0?e:(await A.get(`/cms/popup_modals`)).data?.data||[]},getCourses:async()=>{let e=await P.fetchGroq(Ge);return e&&e.length>0?e:(await A.get(`/courses`)).data?.data||[]},getWorkshops:async()=>{let e=await P.fetchGroq(Ke);return e&&e.length>0?e:(await A.get(`/workshops`)).data?.data||[]}},F={getCmsData:async(e,t=`PUBLISHED`)=>{try{let t=String(e).toLowerCase();if(t===`about`){let e=await P.getAboutPage();if(e)return{success:!0,data:{data:{overview:e,timeline:e.timeline||[]}}}}else if(t===`homepage`){let e=await P.getHomepage();if(e)return{success:!0,data:{data:e}}}else if(t===`contact`){let e=await P.getContactPage();if(e)return{success:!0,data:{data:e}}}else if(t===`navigation`){let e=await P.getNavigation();if(e)return{success:!0,data:{data:e}}}else if(t===`footer`){let e=await P.getFooter();if(e)return{success:!0,data:{data:e}}}else if(t===`site_settings`){let e=await P.getSiteSettings();if(e)return{success:!0,data:{data:e}}}else if(t===`global_faqs`||t===`faqs`||t===`faq`){let e=await P.getFaqs();if(e)return{success:!0,data:{data:e}}}else if(t===`global_exit_intent`||t===`popup_modals`||t===`popups`){let e=await P.getPopupModals();if(e)return{success:!0,data:{data:e}}}else if(t===`programs`||t===`academics`){let e=await P.getPrograms();if(e)return{success:!0,data:{data:{programs:e}}}}else if(t===`events`){let e=await P.getEvents();if(e)return{success:!0,data:{data:e}}}else if(t===`blogs`||t===`blog`||t===`news`){let e=await P.getBlogs();if(e)return{success:!0,data:{data:e}}}else if(t===`gallery`||t===`campus`){let e=await P.getGallery();if(e)return{success:!0,data:{data:e}}}else if(t===`testimonials`){let e=await P.getTestimonials();if(e)return{success:!0,data:{data:e}}}else if(t===`faculty`||t===`mentors`||t===`team`){let e=await P.getMentors();if(e)return{success:!0,data:{data:e}}}else if(t===`collaborations`||t===`recruiters`||t===`partners`){let e=await P.getCollaborations();if(e)return{success:!0,data:{data:e}}}else if(t===`recognitions`||t===`awards`){let e=await P.getRecognitions();if(e)return{success:!0,data:{data:e}}}else if(t===`free_programs`||t===`workshops`){let e=await P.getFreePrograms();if(e)return{success:!0,data:{data:e}}}}catch(e){console.warn(`[cmsService] Sanity resolution failed, trying Express DB:`,e.message)}return(await A.get(`/cms/${e}?status=${t}`)).data},updateCmsData:async(e,t)=>(await A.put(`/cms/${e}`,{data:t})).data,publishCmsData:async(e,t=`Published changes`)=>(await A.post(`/cms/${e}/publish`,{commitMessage:t})).data,getVersionHistory:async e=>(await A.get(`/cms/${e}/versions`)).data,rollbackCmsData:async(e,t)=>(await A.post(`/cms/${e}/rollback`,{versionNumber:t})).data,getCMSData:async function(e,t=`PUBLISHED`){return this.getCmsData(e,t)},updateCMSData:async function(e,t){return this.updateCmsData(e,t)}},Xe=[{name:`Home`,path:`/`},{name:`Admissions`,path:`/admissions`},{name:`Programs`,path:`/programs`},{name:`For Institutions`,path:`/for-institutions`},{name:`Recognitions`,path:`/recognitions`},{name:`Mentors`,path:`/mentors`},{name:`Tejas Insights`,path:`/insights`}],Ze=()=>{let[e,t]=(0,j.useState)(!1),[n,r]=(0,j.useState)(!1),i=w(),{user:a,logout:o}=k(),{data:s}=b({queryKey:[`cms`,`navigation`],queryFn:()=>F.getCMSData(`navigation`),staleTime:60*1e3}),c=s?.data?.data?.links||Xe;return(0,j.useEffect)(()=>{let e=()=>t(window.scrollY>20);return window.addEventListener(`scroll`,e),()=>window.removeEventListener(`scroll`,e)},[]),(0,j.useEffect)(()=>{r(!1)},[i.pathname]),(0,M.jsxs)(`header`,{className:O(`fixed top-0 left-0 right-0 z-40 transition-all duration-300`,e?`bg-white/95 backdrop-blur-md shadow-md py-2.5`:`bg-white py-3.5 border-b border-gray-100`),children:[(0,M.jsxs)(`div`,{className:`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center`,children:[(0,M.jsxs)(x,{to:`/`,className:`flex items-center gap-3 shrink-0 group`,children:[(0,M.jsx)(`div`,{className:`w-10 h-10 sm:w-11 sm:h-11 md:w-12 md:h-12 rounded-full bg-white p-1 shadow-sm ring-2 ring-amber-400/80 flex items-center justify-center shrink-0`,children:(0,M.jsx)(`img`,{src:`/logo.png`,alt:`Tejas Academy of Excellence Logo`,className:`w-full h-full object-contain transition-transform group-hover:scale-105`})}),(0,M.jsxs)(`div`,{className:`flex flex-col justify-center leading-tight`,children:[(0,M.jsx)(`span`,{className:`text-base sm:text-lg md:text-xl font-serif font-extrabold tracking-tight text-gray-900 whitespace-nowrap`,children:`Tejas Academy`}),(0,M.jsx)(`span`,{className:`text-[10px] sm:text-[11px] font-bold text-amber-600 uppercase tracking-widest -mt-0.5 whitespace-nowrap`,children:`of Excellence`})]})]}),(0,M.jsxs)(`nav`,{className:`hidden md:flex items-center gap-6 lg:gap-8`,children:[c.map(e=>(0,M.jsx)(`div`,{className:`relative group`,children:(0,M.jsx)(x,{to:e.url||e.path,className:O(`text-sm font-semibold text-gray-700 hover:text-primary-600 py-2 transition-colors`,i.pathname===(e.url||e.path)&&`text-primary-600 font-bold`),children:e.label||e.name})},e.label||e.name)),a?(0,M.jsxs)(`div`,{className:`relative group`,children:[(0,M.jsxs)(`div`,{className:`flex items-center gap-2 cursor-pointer bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-full pl-2 pr-4 py-1 transition-colors`,children:[(0,M.jsx)(`div`,{className:`w-8 h-8 rounded-full bg-primary-100 text-primary-700 flex items-center justify-center font-bold text-sm`,children:a.name?.[0]||`U`}),(0,M.jsx)(`span`,{className:`text-sm font-medium text-gray-700`,children:a.name?a.name.split(` `)[0]:`Student`}),(0,M.jsx)(h,{className:`w-4 h-4 text-gray-500 transition-transform group-hover:rotate-180`})]}),(0,M.jsxs)(`div`,{className:`absolute top-full right-0 mt-2 w-48 bg-white shadow-xl rounded-xl border border-gray-100 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all flex flex-col py-2`,children:[(0,M.jsxs)(x,{to:[`admin`,`super_admin`].includes(a.role)?`/admin`:`/dashboard`,className:`px-4 py-2 hover:bg-gray-50 text-gray-700 hover:text-primary-600 text-sm font-medium flex items-center gap-2`,children:[(0,M.jsx)(pe,{className:`w-4 h-4`}),` My Dashboard`]}),(0,M.jsxs)(`button`,{onClick:o,className:`px-4 py-2 hover:bg-gray-50 text-red-600 hover:text-red-700 text-sm font-medium flex items-center gap-2 text-left w-full`,children:[(0,M.jsx)(ae,{className:`w-4 h-4`}),` Sign Out`]})]})]}):(0,M.jsxs)(`div`,{className:`flex items-center gap-3`,children:[(0,M.jsx)(N,{variant:`ghost`,size:`sm`,as:x,to:`/login`,className:`hidden lg:inline-flex text-xs font-bold uppercase tracking-wider`,children:`Log In`}),(0,M.jsx)(N,{variant:`primary`,size:`sm`,as:x,to:`/admissions`,className:`text-xs font-bold uppercase tracking-wider`,children:`Apply Now`})]})]}),(0,M.jsx)(`div`,{className:`flex items-center gap-2 md:hidden`,children:(0,M.jsx)(`button`,{className:`p-2 text-gray-700 hover:text-primary-600 rounded-lg border border-gray-200`,onClick:()=>r(!n),"aria-label":`Toggle Navigation Menu`,children:n?(0,M.jsx)(S,{className:`w-6 h-6`}):(0,M.jsx)(m,{className:`w-6 h-6`})})})]}),n&&(0,M.jsxs)(`div`,{className:`md:hidden absolute top-full left-0 right-0 bg-white/98 backdrop-blur-xl border-t border-gray-100 shadow-2xl px-5 py-6 flex flex-col gap-4 animate-in slide-in-from-top-2 duration-200`,children:[c.map(e=>(0,M.jsx)(x,{to:e.url||e.path,className:`text-base font-semibold text-gray-900 border-b border-gray-100 pb-3 hover:text-primary-600 transition-colors`,children:e.label||e.name},e.label||e.name)),a?(0,M.jsxs)(M.Fragment,{children:[(0,M.jsx)(x,{to:[`admin`,`super_admin`].includes(a.role)?`/admin`:`/dashboard`,className:`text-base font-bold text-primary-600 border-b border-gray-100 pb-3`,children:`My Dashboard`}),(0,M.jsx)(`button`,{onClick:o,className:`text-base font-bold text-red-600 text-left pb-3 border-b border-gray-100`,children:`Sign Out`})]}):(0,M.jsxs)(`div`,{className:`flex flex-col gap-3 pt-2`,children:[(0,M.jsx)(N,{variant:`outline`,className:`w-full h-11 text-sm font-bold`,as:x,to:`/login`,children:`Log In`}),(0,M.jsx)(N,{variant:`primary`,className:`w-full h-11 text-sm font-bold`,as:x,to:`/admissions`,children:`Apply for Admissions`})]})]})]})},I=j.forwardRef(({className:e,label:t,error:n,helperText:r,leftIcon:i,rightIcon:a,...o},s)=>{let[c,l]=(0,j.useState)(!1);return(0,M.jsxs)(`div`,{className:`flex flex-col w-full relative`,children:[t&&(0,M.jsx)(`label`,{className:O(`text-sm font-semibold mb-1.5 transition-colors`,n?`text-red-500`:c?`text-primary-600`:`text-gray-700`),children:t}),(0,M.jsxs)(`div`,{className:`relative group`,children:[i&&(0,M.jsx)(`div`,{className:O(`absolute left-3.5 top-1/2 -translate-y-1/2 transition-colors`,c?`text-primary-500`:`text-gray-400`,n&&`text-red-500`),children:i}),(0,M.jsx)(`input`,{ref:s,onFocus:e=>{l(!0),o.onFocus?.(e)},onBlur:e=>{l(!1),o.onBlur?.(e)},className:O(`flex h-12 w-full rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-900 placeholder:text-gray-400 placeholder:font-normal focus:outline-none focus:border-primary-500 focus:ring-4 focus:ring-primary-500/20 disabled:cursor-not-allowed disabled:bg-gray-50 disabled:text-gray-500 transition-all shadow-sm`,i&&`pl-11`,a&&`pr-11`,n&&`border-red-500 focus:border-red-500 focus:ring-red-500/20`,e),...o}),a&&(0,M.jsx)(`div`,{className:`absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400`,children:a})]}),(0,M.jsx)(E,{children:(n||r)&&(0,M.jsx)(D.p,{initial:{opacity:0,y:-5},animate:{opacity:1,y:0},exit:{opacity:0,y:-5},className:O(`text-xs font-medium mt-1.5 ml-1`,n?`text-red-500`:`text-gray-500`),children:n||r})})]})});I.displayName=`Input`;var Qe=d({email:s().email(`Invalid email address`)}),L=()=>{let{register:e,handleSubmit:t,formState:{errors:n,isSubmitting:r},reset:i}=c({resolver:u(Qe)});return(0,M.jsxs)(`form`,{onSubmit:t(async e=>{try{await A.post(`/newsletter`,e),o.success(`Subscribed successfully!`),i()}catch(e){e.response?.status===409?o.error(`You are already subscribed!`):o.error(`Failed to subscribe. Please try again.`)}}),className:`flex flex-col sm:flex-row gap-3 max-w-md w-full`,children:[(0,M.jsx)(`div`,{className:`flex-grow`,children:(0,M.jsx)(I,{placeholder:`Enter your email`,...e(`email`),error:n.email?.message,className:`bg-white/10 text-white border-white/20 placeholder:text-gray-300`})}),(0,M.jsx)(N,{type:`submit`,variant:`primary`,isLoading:r,className:`shrink-0 h-10`,children:`Subscribe`})]})},$e=[{label:`Home`,url:`/`},{label:`Academic Programs`,url:`/programs`},{label:`Admissions & Scholarships`,url:`/admissions`},{label:`Free Learning Programs`,url:`/free-programs`},{label:`For Institutions`,url:`/for-institutions`},{label:`Recognitions & Awards`,url:`/recognitions`},{label:`Faculty & Mentors`,url:`/mentors`},{label:`Our Community`,url:`/about`}],et=()=>{let{data:e}=b({queryKey:[`cms`,`footer`],queryFn:()=>F.getCMSData(`footer`),staleTime:60*1e3}),{data:t}=b({queryKey:[`cms`,`site_settings`],queryFn:()=>F.getCMSData(`site_settings`),staleTime:60*1e3}),n=t?.data?.data||t?.data||t||{},r=e?.data?.data||e?.data||e||{},i={address:n.physicalAddress||`Beside L K Towers, Roy Nagar, Gannavaram - 521101`,phone:n.contactPhone||`+91 98765 43210`,email:n.contactEmail||`info@unlocktejas.com`},a=r.quickLinks&&r.quickLinks.length>0?r.quickLinks:$e,o=r.legalLinks&&r.legalLinks.length>0?r.legalLinks:[{label:`Privacy Policy`,url:`/privacy`},{label:`Terms of Service`,url:`/terms`}],s=r.copyrightText||`© ${new Date().getFullYear()} Tejas Academy of Excellence. All rights reserved.`,c=r.accreditationText||`Approved by UGC & AICTE, Govt. of India.`;return(0,M.jsxs)(`footer`,{className:`bg-[#1b2a1c] text-emerald-100 font-sans border-t border-emerald-900/60 select-none`,children:[(0,M.jsx)(`div`,{className:`border-b border-emerald-800/40 bg-gradient-to-r from-[#172418] via-[#1f3120] to-[#172418]`,children:(0,M.jsxs)(`div`,{className:`max-w-7xl mx-auto px-6 py-12 md:py-16 flex flex-col md:flex-row items-center justify-between gap-8`,children:[(0,M.jsxs)(`div`,{className:`text-center md:text-left max-w-2xl`,children:[(0,M.jsx)(`h2`,{className:`text-2xl md:text-4xl font-serif font-bold text-white mb-2 tracking-tight`,children:`Ready to redefine your future with Tejas?`}),(0,M.jsx)(`p`,{className:`text-emerald-200/80 text-sm md:text-base`,children:`Join a community of ambitious leaders, innovators, and entrepreneurs building the world of tomorrow.`})]}),(0,M.jsx)(`div`,{className:`flex shrink-0 gap-4 w-full md:w-auto`,children:(0,M.jsx)(N,{variant:`gold`,size:`lg`,as:x,to:`/admissions`,rightIcon:(0,M.jsx)(de,{size:18}),className:`w-full md:w-auto text-sm font-bold shadow-xl shadow-amber-500/20`,children:`Apply for Admissions`})})]})}),(0,M.jsx)(`div`,{className:`max-w-7xl mx-auto px-6 py-16`,children:(0,M.jsxs)(`div`,{className:`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-8`,children:[(0,M.jsxs)(`div`,{className:`lg:col-span-4`,children:[(0,M.jsxs)(x,{to:`/`,className:`flex items-center gap-3 mb-5 group inline-flex`,children:[(0,M.jsx)(`div`,{className:`w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white p-1 shadow-md ring-2 ring-amber-400/80 flex items-center justify-center shrink-0`,children:(0,M.jsx)(`img`,{src:`/logo.png`,alt:`Tejas Academy Logo`,className:`w-full h-full object-contain transition-transform group-hover:scale-105`})}),(0,M.jsxs)(`div`,{className:`flex flex-col leading-tight`,children:[(0,M.jsx)(`span`,{className:`text-white text-xl font-serif font-extrabold tracking-tight`,children:`Tejas Academy`}),(0,M.jsx)(`span`,{className:`text-[10px] font-bold text-amber-300 uppercase tracking-widest -mt-0.5`,children:`of Excellence`})]})]}),(0,M.jsx)(`p`,{className:`text-sm text-emerald-200/75 leading-relaxed mb-8 max-w-sm`,children:`Empowering the next generation of global leaders through world-class education, deep-tech innovation, and holistic human development.`}),(0,M.jsxs)(`div`,{className:`flex gap-3`,children:[(0,M.jsx)(`a`,{href:`#`,className:`w-10 h-10 rounded-full bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-200 hover:bg-amber-500 hover:text-white hover:border-amber-400 transition-all duration-300`,children:(0,M.jsx)(be,{size:18})}),(0,M.jsx)(`a`,{href:`#`,className:`w-10 h-10 rounded-full bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-200 hover:bg-amber-500 hover:text-white hover:border-amber-400 transition-all duration-300`,children:(0,M.jsx)(le,{size:18})}),(0,M.jsx)(`a`,{href:`#`,className:`w-10 h-10 rounded-full bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-200 hover:bg-amber-500 hover:text-white hover:border-amber-400 transition-all duration-300`,children:(0,M.jsx)(he,{size:18})}),(0,M.jsx)(`a`,{href:`#`,className:`w-10 h-10 rounded-full bg-emerald-900/60 border border-emerald-700/50 flex items-center justify-center text-emerald-200 hover:bg-amber-500 hover:text-white hover:border-amber-400 transition-all duration-300`,children:(0,M.jsx)(ce,{size:18})})]})]}),(0,M.jsxs)(`div`,{className:`lg:col-span-2`,children:[(0,M.jsx)(`h4`,{className:`text-white font-bold text-xs tracking-widest uppercase mb-5 text-amber-400`,children:`Quick Links`}),(0,M.jsx)(`ul`,{className:`space-y-3`,children:a.slice(0,Math.ceil(a.length/2)).map((e,t)=>(0,M.jsx)(`li`,{children:(0,M.jsx)(x,{to:e.url,className:`text-sm text-emerald-200/80 hover:text-white hover:translate-x-1 inline-block transition-all duration-200 font-medium`,children:e.label})},t))})]}),(0,M.jsxs)(`div`,{className:`lg:col-span-2`,children:[(0,M.jsx)(`h4`,{className:`text-white font-bold text-xs tracking-widest uppercase mb-5 text-amber-400`,children:`More Links`}),(0,M.jsx)(`ul`,{className:`space-y-3`,children:a.slice(Math.ceil(a.length/2)).map((e,t)=>(0,M.jsx)(`li`,{children:(0,M.jsx)(x,{to:e.url,className:`text-sm text-emerald-200/80 hover:text-white hover:translate-x-1 inline-block transition-all duration-200 font-medium`,children:e.label})},t))})]}),(0,M.jsxs)(`div`,{className:`lg:col-span-4`,children:[(0,M.jsx)(`h4`,{className:`text-white font-bold text-xs tracking-widest uppercase mb-5 text-amber-400`,children:`Get in Touch`}),(0,M.jsxs)(`ul`,{className:`space-y-3.5 mb-8`,children:[(0,M.jsxs)(`li`,{className:`flex items-start gap-3 group`,children:[(0,M.jsx)(_,{className:`w-5 h-5 text-amber-400 shrink-0 mt-0.5`}),(0,M.jsx)(`span`,{className:`text-sm text-emerald-200/80 leading-relaxed`,children:i.address})]}),(0,M.jsxs)(`li`,{className:`flex items-center gap-3 group`,children:[(0,M.jsx)(p,{className:`w-5 h-5 text-amber-400 shrink-0`}),(0,M.jsx)(`span`,{className:`text-sm text-emerald-200/80 font-medium`,children:i.phone})]}),(0,M.jsxs)(`li`,{className:`flex items-center gap-3 group`,children:[(0,M.jsx)(oe,{className:`w-5 h-5 text-amber-400 shrink-0`}),(0,M.jsx)(`span`,{className:`text-sm text-emerald-200/80 font-medium`,children:i.email})]})]}),(0,M.jsxs)(`div`,{className:`bg-emerald-950/60 border border-emerald-800/60 rounded-2xl p-5 backdrop-blur-sm`,children:[(0,M.jsx)(`h5`,{className:`text-white text-sm font-bold mb-2`,children:`Subscribe to Tejas Insights`}),(0,M.jsx)(`p`,{className:`text-xs text-emerald-300/80 mb-3`,children:`Get monthly perspectives on leadership & tech innovation.`}),(0,M.jsx)(L,{})]})]})]})}),(0,M.jsx)(`div`,{className:`border-t border-emerald-900/80 bg-[#121c13]`,children:(0,M.jsxs)(`div`,{className:`max-w-7xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-4`,children:[(0,M.jsxs)(`p`,{className:`text-emerald-400/80 text-xs`,children:[s,` `,c]}),(0,M.jsxs)(`div`,{className:`flex items-center gap-6 text-xs text-emerald-400/80 font-medium`,children:[o.map((e,t)=>(0,M.jsx)(x,{to:e.url,className:`hover:text-white transition-colors`,children:e.label},t)),(0,M.jsx)(x,{to:`/sitemap.xml`,className:`hover:text-white transition-colors`,children:`Sitemap`})]})]})})]})},tt=()=>{let{pathname:e}=w();return(0,j.useEffect)(()=>{window.scrollTo({top:0,left:0,behavior:`smooth`})},[e]),null},nt=({className:e})=>{let t=w().pathname.split(`/`).filter(e=>e);return t.length===0?null:(0,M.jsx)(`nav`,{className:O(`flex py-4 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-sm text-gray-500`,e),"aria-label":`Breadcrumb`,children:(0,M.jsxs)(`ol`,{className:`inline-flex items-center space-x-1 md:space-x-3`,children:[(0,M.jsx)(`li`,{className:`inline-flex items-center`,children:(0,M.jsxs)(x,{to:`/`,className:`inline-flex items-center hover:text-primary-600 transition-colors`,children:[(0,M.jsx)(y,{className:`w-4 h-4 mr-2`}),`Home`]})}),t.map((e,n)=>{let r=n===t.length-1,i=`/${t.slice(0,n+1).join(`/`)}`;return(0,M.jsx)(`li`,{children:(0,M.jsxs)(`div`,{className:`flex items-center`,children:[(0,M.jsx)(re,{className:`w-4 h-4 text-gray-400 mx-1`}),r?(0,M.jsx)(`span`,{className:`text-gray-900 font-medium capitalize`,children:e.replace(/-/g,` `)}):(0,M.jsx)(x,{to:i,className:`hover:text-primary-600 transition-colors capitalize`,children:e.replace(/-/g,` `)})]})},i)})]})})},R=({children:e,allowedRoles:t})=>{let{isAuthenticated:n,user:r}=k(),i=w();return n?t&&!t.includes(r?.role)?(0,M.jsx)(v,{to:`/`,replace:!0}):e:(0,M.jsx)(v,{to:`/login`,state:{from:i},replace:!0})},rt=()=>{let[e,t]=(0,j.useState)(!1),{data:n}=b({queryKey:[`cms`,`global_quick_connect`],queryFn:()=>F.getCMSData(`global_quick_connect`)}),r=n?.data?.data||{isActive:!0,whatsappNumber:`1234567890`,whatsappMessage:`Hello, I would like to know more about Tejas Academy.`,contactUrl:`/contact`,brochureUrl:`/brochure.pdf`};return r.isActive?(0,M.jsxs)(`div`,{className:`fixed bottom-6 right-6 z-50 flex flex-col items-end`,children:[(0,M.jsx)(E,{children:e&&(0,M.jsxs)(D.div,{initial:{opacity:0,y:20,scale:.9},animate:{opacity:1,y:0,scale:1},exit:{opacity:0,y:20,scale:.9},className:`mb-4 bg-white rounded-2xl shadow-xl border border-gray-100 p-2 w-64 overflow-hidden`,children:[(0,M.jsxs)(`div`,{className:`p-3 bg-gray-50 border-b border-gray-100 rounded-t-xl mb-2`,children:[(0,M.jsx)(`h4`,{className:`font-bold text-gray-900 text-sm`,children:`Need Help?`}),(0,M.jsx)(`p`,{className:`text-xs text-gray-500`,children:`Choose how you'd like to connect.`})]}),(0,M.jsxs)(`a`,{href:`https://wa.me/${r.whatsappNumber}?text=${encodeURIComponent(r.whatsappMessage)}`,target:`_blank`,rel:`noreferrer`,className:`flex items-center gap-3 w-full p-3 hover:bg-green-50 rounded-lg transition-colors group text-left`,children:[(0,M.jsx)(`div`,{className:`bg-green-100 text-green-600 p-2 rounded-full group-hover:scale-110 transition-transform`,children:(0,M.jsx)(ie,{size:16})}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`p`,{className:`text-sm font-semibold text-gray-900`,children:`WhatsApp Chat`}),(0,M.jsx)(`p`,{className:`text-xs text-gray-500`,children:`Typically replies in 5m`})]})]}),(0,M.jsxs)(`button`,{onClick:()=>window.location.href=r.contactUrl,className:`flex items-center gap-3 w-full p-3 hover:bg-blue-50 rounded-lg transition-colors group text-left mt-1`,children:[(0,M.jsx)(`div`,{className:`bg-blue-100 text-blue-600 p-2 rounded-full group-hover:scale-110 transition-transform`,children:(0,M.jsx)(p,{size:16})}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`p`,{className:`text-sm font-semibold text-gray-900`,children:`Request a Call`}),(0,M.jsx)(`p`,{className:`text-xs text-gray-500`,children:`Speak to an advisor`})]})]}),(0,M.jsxs)(`button`,{onClick:()=>window.open(r.brochureUrl,`_blank`),className:`flex items-center gap-3 w-full p-3 hover:bg-accent-50 rounded-lg transition-colors group text-left mt-1 border-t border-gray-100`,children:[(0,M.jsx)(`div`,{className:`bg-accent-100 text-accent-600 p-2 rounded-full group-hover:scale-110 transition-transform`,children:(0,M.jsx)(fe,{size:16})}),(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`p`,{className:`text-sm font-semibold text-gray-900`,children:`Download Brochure`}),(0,M.jsx)(`p`,{className:`text-xs text-gray-500`,children:`Get complete program details`})]})]})]})}),(0,M.jsx)(`button`,{onClick:()=>t(!e),className:`w-14 h-14 bg-primary-900 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all focus:outline-none focus:ring-4 focus:ring-primary-900/30 group`,children:(0,M.jsx)(E,{mode:`wait`,children:e?(0,M.jsx)(D.div,{initial:{rotate:-90,opacity:0},animate:{rotate:0,opacity:1},exit:{rotate:90,opacity:0},children:(0,M.jsx)(S,{size:24})},`close`):(0,M.jsx)(D.div,{initial:{rotate:90,opacity:0},animate:{rotate:0,opacity:1},exit:{rotate:-90,opacity:0},children:(0,M.jsx)(xe,{size:28,className:`group-hover:animate-pulse`})},`open`)})})]}):null},it=()=>{let[e,t]=(0,j.useState)(null),{data:n}=b({queryKey:[`cms`,`global_social_proof`],queryFn:()=>F.getCMSData(`global_social_proof`)}),r=n?.data?.data||{isActive:!1,notifications:[]};(0,j.useEffect)(()=>{if(!r.isActive||!r.notifications||r.notifications.length===0)return;let e,t=setTimeout(()=>{i(),e=setInterval(()=>{i()},45e3+Math.random()*15e3)},1e4);return()=>{clearTimeout(t),clearInterval(e)}},[r.isActive,r.notifications]);let i=()=>{if(!r.notifications||r.notifications.length===0)return;let e=r.notifications[Math.floor(Math.random()*r.notifications.length)];t(e),setTimeout(()=>{t(null)},6e3)};return r.isActive?(0,M.jsx)(`div`,{className:`fixed bottom-6 left-6 z-40 pointer-events-none`,children:(0,M.jsx)(E,{children:e&&(0,M.jsxs)(D.div,{initial:{opacity:0,y:50,x:-50},animate:{opacity:1,y:0,x:0},exit:{opacity:0,y:20,scale:.9},className:`bg-white rounded-xl shadow-lg border border-gray-100 p-4 w-72 flex items-start gap-4 pointer-events-auto`,children:[(0,M.jsx)(`div`,{className:`w-10 h-10 rounded-full bg-gradient-to-br from-primary-100 to-accent-100 border border-primary-200 flex items-center justify-center shrink-0 text-primary-700 font-bold text-sm`,children:e.name?.charAt(0)||`U`}),(0,M.jsxs)(`div`,{children:[(0,M.jsxs)(`p`,{className:`text-sm text-gray-900 leading-snug`,children:[(0,M.jsx)(`span`,{className:`font-bold`,children:e.name}),` from `,e.city,` `,(0,M.jsx)(`span`,{className:`text-gray-600`,children:e.action})]}),(0,M.jsx)(`p`,{className:`text-xs text-gray-400 mt-1 font-medium`,children:e.time})]})]})})}):null},at=()=>{let[e,t]=(0,j.useState)(window.navigator.onLine);return(0,j.useEffect)(()=>{let e=()=>{t(window.navigator.onLine),window.navigator.onLine?o.success(`You're back online!`):o.error(`You are offline. Please check your internet connection.`,{duration:5e3})};return window.addEventListener(`offline`,e),window.addEventListener(`online`,e),()=>{window.removeEventListener(`offline`,e),window.removeEventListener(`online`,e)}},[]),e},ot=`https://unlocktejas.com/api/v1`,st=()=>typeof crypto<`u`&&crypto.randomUUID?crypto.randomUUID():`vid_`+Math.random().toString(36).substring(2,11)+Date.now().toString(36),z=new class{constructor(){this.visitorId=this.getOrCreateVisitorId(),this.sessionStart=Date.now(),this.source=this.detectSource(),this.device=this.detectDevice()}getOrCreateVisitorId(){let e=localStorage.getItem(`_ta_vid`);return e||(e=st(),localStorage.setItem(`_ta_vid`,e)),e}detectSource(){let e=document.referrer;return e?e.includes(`google`)||e.includes(`bing`)||e.includes(`yahoo`)?`organic`:e.includes(`facebook`)||e.includes(`twitter`)||e.includes(`linkedin`)||e.includes(`instagram`)?`social`:e.includes(`utm_medium=email`)?`email`:e.includes(`utm_medium=cpc`)||e.includes(`gclid`)?`paid`:`referral`:`direct`}detectDevice(){let e=navigator.userAgent;return/tablet|ipad/i.test(e)?`tablet`:/mobile|android|iphone/i.test(e)?`mobile`:`desktop`}async send(e,t={}){try{await l.post(`${ot}/analytics/track`,{event:e,page:window.location.pathname,referrer:document.referrer,source:this.source,device:this.device,browser:navigator.userAgent.split(` `).pop(),visitorId:this.visitorId,sessionDuration:Math.floor((Date.now()-this.sessionStart)/1e3),metadata:t})}catch{}}trackPageView(){this.send(`page_view`)}trackSessionStart(){this.send(`session_start`)}trackSearch(e){this.send(`search_query`,{searchTerm:e})}trackProgramView(e,t){this.send(`program_view`,{programId:e,programName:t})}trackCTAClick(e,t){this.send(`cta_click`,{ctaLabel:e,ctaLocation:t})}trackFormSubmit(e){this.send(`form_submit`,{formName:e})}trackBounce(){this.send(`bounce`)}},ct=()=>{let e=w();(0,j.useEffect)(()=>{z.trackSessionStart()},[]),(0,j.useEffect)(()=>{z.trackPageView()},[e.pathname])},B=({title:e,description:t,keywords:n,image:r=`https://res.cloudinary.com/dvfpt33g3/image/upload/v1731671239/tejas_logo_main.png`,url:i=`https://unlocktejas.com`,type:a=`website`,schema:o})=>{let s=`${e} | Tejas Academy of Excellence`;return(0,M.jsxs)(me,{children:[(0,M.jsx)(`title`,{children:s}),(0,M.jsx)(`meta`,{name:`description`,content:t}),n&&(0,M.jsx)(`meta`,{name:`keywords`,content:n}),(0,M.jsx)(`link`,{rel:`canonical`,href:i}),(0,M.jsx)(`meta`,{property:`og:type`,content:a}),(0,M.jsx)(`meta`,{property:`og:url`,content:i}),(0,M.jsx)(`meta`,{property:`og:title`,content:s}),(0,M.jsx)(`meta`,{property:`og:description`,content:t}),(0,M.jsx)(`meta`,{property:`og:image`,content:r}),(0,M.jsx)(`meta`,{property:`twitter:card`,content:`summary_large_image`}),(0,M.jsx)(`meta`,{property:`twitter:url`,content:i}),(0,M.jsx)(`meta`,{property:`twitter:title`,content:s}),(0,M.jsx)(`meta`,{property:`twitter:description`,content:t}),(0,M.jsx)(`meta`,{property:`twitter:image`,content:r}),o&&(0,M.jsx)(`script`,{type:`application/ld+json`,children:JSON.stringify(o)})]})};function lt(...e){return n(i(e))}var ut=`
attribute vec2 position;
varying vec2 vUv;
void main() {
  vUv = position * 0.5 + 0.5;
  gl_Position = vec4(position, 0.0, 1.0);
}
`,dt=`
precision highp float;
varying vec2 vUv;

uniform vec2  u_resolution;
uniform float u_time;
uniform float u_grain;
uniform vec3  u_colors[4];
uniform vec3  u_bg;

vec3 permute(vec3 x) { return mod(((x*34.0)+1.0)*x, 289.0); }

float snoise(vec2 v){
  const vec4 C = vec4(0.211324865405187, 0.366025403784439,
           -0.577350269189626, 0.024390243902439);
  vec2 i  = floor(v + dot(v, C.yy) );
  vec2 x0 = v -   i + dot(i, C.xx);
  vec2 i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
  vec4 x12 = x0.xyxy + C.xxzz;
  x12.xy -= i1;
  i = mod(i, 289.0);
  vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 ))
  + i.x + vec3(0.0, i1.x, 1.0 ));
  vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy),
    dot(x12.zw,x12.zw)), 0.0);
  m = m*m ;
  m = m*m ;
  vec3 x = 2.0 * fract(p * C.www) - 1.0;
  vec3 h = abs(x) - 0.5;
  vec3 ox = floor(x + 0.5);
  vec3 a0 = x - ox;
  m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
  vec3 g;
  g.x  = a0.x  * x0.x  + h.x  * x0.y;
  g.yz = a0.yz * x12.xz + h.yz * x12.yw;
  return 130.0 * dot(m, g);
}

void main() {
  vec2 uv = vUv;
  float ratio = u_resolution.x / u_resolution.y;
  vec2 p = uv - 0.5;
  p.x *= ratio;

  float t = u_time * 0.1;

  float n1 = snoise(p * 0.4 + vec2(t * 0.2, -t * 0.3));
  float n2 = snoise(p * 0.55 + vec2(-t * 0.15, t * 0.25) + n1 * 0.25);
  float n3 = snoise(p * 0.75 + vec2(t * 0.1, -t * 0.2) + n2 * 0.2);

  vec3 col = u_bg;
  
  float dist = length(p) * 1.5;
  float vignette = 1.0 - smoothstep(0.3, 1.2, dist);
  
  col = mix(col, u_colors[0], smoothstep(-0.2, 0.5, n1) * 0.85);
  col = mix(col, u_colors[1], smoothstep(-0.1, 0.6, n2) * 0.7);
  col = mix(col, u_colors[2], smoothstep(-0.3, 0.4, n3) * 0.6);
  col = mix(col, u_colors[3], smoothstep(0.0, 0.7, n1 * n2) * 0.5);

  float glow = smoothstep(0.8, 0.0, dist) * 0.3;
  col += u_colors[1] * glow;

  col = mix(col * 0.2, col, vignette);

  float grain = fract(sin(dot(uv, vec2(12.9898, 78.233))) * 43758.5453 + u_time);
  col += (grain - 0.5) * u_grain * 0.1;

  gl_FragColor = vec4(col, 1.0);
}
`,ft=[`#86efac`,`#4ade80`,`#059669`,`#000000`],pt=({bg:e=`#000000`,colors:t=ft,speed:n=2,grain:r=.3,height:i=`100vh`,className:a,children:o})=>{let s=(0,j.useRef)(null),c=(0,j.useRef)(null),l=e=>{let t=e.replace(`#`,``);return[parseInt(t.slice(0,2),16)/255,parseInt(t.slice(2,4),16)/255,parseInt(t.slice(4,6),16)/255]};return(0,j.useEffect)(()=>{let i=s.current,a=c.current;if(!i||!a)return;let o=i.getContext(`webgl`);if(!o)return;let u=(e,t)=>{let n=o.createShader(e);return o.shaderSource(n,t),o.compileShader(n),n},d=o.createProgram();o.attachShader(d,u(o.VERTEX_SHADER,ut)),o.attachShader(d,u(o.FRAGMENT_SHADER,dt)),o.linkProgram(d),o.useProgram(d);let f=o.createBuffer();o.bindBuffer(o.ARRAY_BUFFER,f),o.bufferData(o.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),o.STATIC_DRAW);let p=o.getAttribLocation(d,`position`);o.enableVertexAttribArray(p),o.vertexAttribPointer(p,2,o.FLOAT,!1,0,0);let m={res:o.getUniformLocation(d,`u_resolution`),time:o.getUniformLocation(d,`u_time`),grain:o.getUniformLocation(d,`u_grain`),colors:o.getUniformLocation(d,`u_colors`),bg:o.getUniformLocation(d,`u_bg`)},h=new ResizeObserver(()=>{let e=Math.min(window.devicePixelRatio,2);i.width=a.clientWidth*e,i.height=a.clientHeight*e,o.viewport(0,0,i.width,i.height)});h.observe(a);let g,_=a=>{o.uniform2f(m.res,i.width,i.height),o.uniform1f(m.time,a*.001*n),o.uniform1f(m.grain,r),o.uniform3f(m.bg,...l(e));let s=new Float32Array(t.slice(0,4).flatMap(l));o.uniform3fv(m.colors,s),o.drawArrays(o.TRIANGLE_STRIP,0,4),g=requestAnimationFrame(_)};return g=requestAnimationFrame(_),()=>{h.disconnect(),cancelAnimationFrame(g)}},[e,t,n,r]),(0,M.jsxs)(`div`,{ref:c,style:{height:i},className:lt(`relative w-full overflow-hidden`,a),children:[(0,M.jsx)(`canvas`,{ref:s,className:`pointer-events-none absolute inset-0 h-full w-full`}),(0,M.jsx)(`div`,{className:`relative z-10 h-full w-full`,children:o})]})},mt=({bg:e=`#070d08`,colors:t=[`#d49e35`,`#10b981`,`#059669`,`#0b140c`],speed:n=1,grain:r=.2,opacity:i=.25})=>(0,M.jsx)(`div`,{className:`fixed inset-0 -z-10 pointer-events-none overflow-hidden transition-opacity duration-1000`,style:{opacity:i},"aria-hidden":`true`,children:(0,M.jsx)(pt,{bg:e,colors:t,speed:n,grain:r,height:`100vh`,className:`w-full h-full`})}),V=()=>(0,M.jsx)(`div`,{className:`flex items-center justify-center min-h-[50vh]`,children:(0,M.jsx)(`div`,{className:`w-12 h-12 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin`})}),ht=j.lazy(()=>C(()=>import(`./Home-BFUJqUKL.js`).then(e=>({default:e.default||e.Home})),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16]))),gt=j.lazy(()=>C(()=>import(`./About-BiSxandE.js`).then(e=>({default:e.default||e.About})),__vite__mapDeps([17,1,2,3,4,18,13]))),_t=j.lazy(()=>C(()=>import(`./VisionMission-DnocIOCU.js`).then(e=>({default:e.default||e.VisionMission})),__vite__mapDeps([19,1,2,3,4,18,13]))),vt=j.lazy(()=>C(()=>import(`./Campus-Dbe36yb6.js`).then(e=>({default:e.default||e.Campus})),__vite__mapDeps([20,1,2,3,4,18,13]))),yt=j.lazy(()=>C(()=>import(`./Programs-Vhj8IXfX.js`).then(e=>({default:e.default||e.Programs})),__vite__mapDeps([21,1,2,3,4,5,6,7,11,12,13]))),bt=j.lazy(()=>C(()=>import(`./ProgramDetails-CX3-On4i.js`).then(e=>({default:e.default||e.ProgramDetails})),__vite__mapDeps([22,1,2,3,4,6,7,18,13,23]))),xt=j.lazy(()=>C(()=>import(`./Admissions-BRrB-qyy.js`).then(e=>({default:e.default||e.Admissions})),__vite__mapDeps([24,1,2,3,4,13,6,7,18,25,5]))),St=j.lazy(()=>C(()=>import(`./Mentors-rodB18nB.js`).then(e=>({default:e.default||e.Mentors})),__vite__mapDeps([26,1,2,3,4,18,13]))),Ct=j.lazy(()=>C(()=>import(`./Events-C-sKtN8K.js`).then(e=>({default:e.default||e.Events})),__vite__mapDeps([27,1,2,3,4,9,10,6,7]))),wt=j.lazy(()=>C(()=>import(`./Gallery-b_ruNx35.js`).then(e=>({default:e.default||e.Gallery})),__vite__mapDeps([28,1,2,4,18,13]))),Tt=j.lazy(()=>C(()=>import(`./Blog-BtoIkFaC.js`).then(e=>({default:e.default||e.Blog})),__vite__mapDeps([29,1,2,3,4,18,13,12,30,6,7,8]))),Et=j.lazy(()=>C(()=>import(`./BlogDetails-DL2vPKIs.js`).then(e=>({default:e.default||e.BlogDetails})),__vite__mapDeps([31,1,2,3,4,12,13,30,6,7]))),Dt=j.lazy(()=>C(()=>import(`./Resources-mJ4wEY99.js`).then(e=>({default:e.default||e.Resources})),__vite__mapDeps([32,1,2,3,4,7,18,13]))),Ot=j.lazy(()=>C(()=>import(`./Placements-1kyK2g6v.js`).then(e=>({default:e.default||e.Placements})),__vite__mapDeps([33,1,2,3,4,18,13]))),kt=j.lazy(()=>C(()=>import(`./Testimonials-AMiVwLFB.js`).then(e=>({default:e.default||e.Testimonials})),__vite__mapDeps([34,1,2,3,4,18,13,14,15,6,7]))),At=j.lazy(()=>C(()=>import(`./FreePrograms-CDSdXeKZ.js`).then(e=>({default:e.default||e.FreePrograms})),__vite__mapDeps([35,1,2,3,4,18,13]))),jt=j.lazy(()=>C(()=>import(`./ForInstitutions-C9p5WutC.js`).then(e=>({default:e.default||e.ForInstitutions})),__vite__mapDeps([36,1,2,3,4,18,13]))),Mt=j.lazy(()=>C(()=>import(`./Recognitions-BnS6f2NX.js`).then(e=>({default:e.default||e.Recognitions})),__vite__mapDeps([37,1,2,3,4,18,13]))),Nt=j.lazy(()=>C(()=>import(`./Contact-BoEFbPLE.js`).then(e=>({default:e.default||e.Contact})),__vite__mapDeps([38,1,2,3,4,6,7,18,13,39]))),Pt=j.lazy(()=>C(()=>import(`./Career-CgYDHgAM.js`).then(e=>({default:e.default||e.Career})),__vite__mapDeps([40,1,2,3,4,18,13]))),Ft=j.lazy(()=>C(()=>import(`./Support-oTWDrpDC.js`).then(e=>({default:e.Support})),__vite__mapDeps([41,1,2,4,18,13,16,3]))),It=j.lazy(()=>C(()=>import(`./Privacy-DayuVIWL.js`).then(e=>({default:e.Privacy})),__vite__mapDeps([42,1,2,3,4,18,13]))),Lt=j.lazy(()=>C(()=>import(`./Terms-CvtZDWfJ.js`).then(e=>({default:e.Terms})),__vite__mapDeps([43,1,2,3,4,18,13]))),Rt=j.lazy(()=>C(()=>import(`./NotFound-Dz94w6PS.js`).then(e=>({default:e.NotFound})),__vite__mapDeps([44,1,2,3,4]))),zt=j.lazy(()=>C(()=>import(`./JoinUs-Cg51oCZo.js`).then(e=>({default:e.JoinUs})),__vite__mapDeps([45,1,2,3,4,18,13]))),Bt=j.lazy(()=>C(()=>import(`./Login-DQhUhwnm.js`),__vite__mapDeps([46,1,2,3,4,7,6]))),Vt=j.lazy(()=>C(()=>import(`./Register-CZPnRvyv.js`),__vite__mapDeps([47,1,2,3,4,7,6]))),Ht=j.lazy(()=>C(()=>import(`./ForgotPassword-BoggxTrk.js`),__vite__mapDeps([48,1,2,3,4,6,7]))),H=j.lazy(()=>C(()=>import(`./ResetPassword-2X-t3TCL.js`),__vite__mapDeps([49,1,2,3,4,6,7]))),Ut=j.lazy(()=>C(()=>import(`./StudentDashboard-DWgpDYtC.js`).then(e=>({default:e.StudentDashboard})),__vite__mapDeps([50,1,2,3,4,13,7,51,10,6,52,53]))),Wt=j.lazy(()=>C(()=>import(`./FacultyDashboard-D1xGhDPe.js`).then(e=>({default:e.FacultyDashboard})),__vite__mapDeps([54,1,2,3,4,7]))),Gt=j.lazy(()=>C(()=>import(`./AdminLayout-DkGjZq0o.js`).then(e=>({default:e.AdminLayout})),__vite__mapDeps([55,1,2,3,4,7,6,51]))),Kt=j.lazy(()=>C(()=>import(`./DashboardHome-Cx0DNd90.js`),__vite__mapDeps([56,1,2,3,4,13,7,57,6]))),qt=j.lazy(()=>C(()=>import(`./ManageStudents-0osIrvVT.js`),__vite__mapDeps([58,1,2,3,4,25,13,12,59,60,61,6,7,53]))),Jt=j.lazy(()=>C(()=>import(`./StudentProfile-XPxjUkM2.js`),__vite__mapDeps([62,1,2,3,4,12,13,23,61,6,7]))),Yt=j.lazy(()=>C(()=>import(`./ManageAdmissions-CJq_Vwjt.js`),__vite__mapDeps([63,1,2,3,4,12,13,23,52,6,7,59,64]))),Xt=j.lazy(()=>C(()=>import(`./ApplicationDetails-a2vEHjyz.js`),__vite__mapDeps([65,1,2,3,4,12,13,23,52,6,7]))),Zt=j.lazy(()=>C(()=>import(`./ManageInquiries-D-cW3oPO.js`),__vite__mapDeps([66,1,2,3,4,6,7,12,13,64]))),Qt=j.lazy(()=>C(()=>import(`./ManagePrograms-DXADxVLv.js`),__vite__mapDeps([67,1,2,3,4,5,6,7,12,13,23,59,60]))),U=j.lazy(()=>C(()=>import(`./ProgramForm-DifBY6qY.js`),__vite__mapDeps([68,1,2,3,4,6,7,5,39,13,23]))),$t=j.lazy(()=>C(()=>import(`./ManageMentors-DAhADQ8R.js`),__vite__mapDeps([69,1,2,3,4,59,13,60,70,6,7]))),W=j.lazy(()=>C(()=>import(`./MentorForm-DsLt8EE5.js`),__vite__mapDeps([71,1,2,3,4,39,13,70,6,7]))),en=j.lazy(()=>C(()=>import(`./ManageEvents-DBrj-jU8.js`),__vite__mapDeps([72,1,2,3,4,12,13,10,6,7,59,60]))),G=j.lazy(()=>C(()=>import(`./EventForm-CoIJ4ZA2.js`),__vite__mapDeps([73,1,2,3,4,39,13,10,6,7,23]))),tn=j.lazy(()=>C(()=>import(`./ManageWorkshops-BRRvjlVv.js`),__vite__mapDeps([74,1,2,3,4,59,13,60,75,6,7]))),K=j.lazy(()=>C(()=>import(`./WorkshopForm-Bmw6JZb3.js`),__vite__mapDeps([76,1,2,3,4,39,13,75,6,7]))),nn=j.lazy(()=>C(()=>import(`./ManageCourses-DzFSCZYK.js`),__vite__mapDeps([77,1,2,3,4,12,13,23,59,60,78,6,7]))),q=j.lazy(()=>C(()=>import(`./CourseForm-UZdl-yvA.js`),__vite__mapDeps([79,1,2,3,4,6,7,5,39,13,23,78]))),rn=j.lazy(()=>C(()=>import(`./ManageBlogs-26CeLMMH.js`),__vite__mapDeps([80,1,2,3,4,30,6,7,59,13,60]))),J=j.lazy(()=>C(()=>import(`./BlogForm-BZRF0i1K.js`),__vite__mapDeps([81,1,2,3,4,30,6,7,39,13,23]))),an=j.lazy(()=>C(()=>import(`./ManageGallery-wfIHbsuG.js`),__vite__mapDeps([82,1,2,3,4,6,7,39,13,59,60]))),on=j.lazy(()=>C(()=>import(`./ManageHomepage-DGZcuk_G.js`),__vite__mapDeps([83,1,2,3,4,39,13]))),sn=j.lazy(()=>C(()=>import(`./ManageAbout-BmiJ29Nv.js`),__vite__mapDeps([84,1,2,3,4,39,13]))),cn=j.lazy(()=>C(()=>import(`./ManageSEO-CbLVDurU.js`),__vite__mapDeps([85,1,2,3,4,39,13]))),Y=j.lazy(()=>C(()=>import(`./ManageSettings-BSB6dU8v.js`),__vite__mapDeps([86,1,2,3,4,39,13]))),ln=j.lazy(()=>C(()=>import(`./ManageNotifications-C4YugMH8.js`),__vite__mapDeps([87,1,2,3,4]))),un=j.lazy(()=>C(()=>import(`./ManageFAQ-DjPfVmvl.js`),__vite__mapDeps([88,1,2,3,4,39,13]))),dn=j.lazy(()=>C(()=>import(`./ManageNavigation-gJEB3GNG.js`),__vite__mapDeps([89,1,2,3,4]))),fn=j.lazy(()=>C(()=>import(`./ManageCampus-Dh3BtLnV.js`),__vite__mapDeps([90,1,2,3,4,39,13]))),pn=j.lazy(()=>C(()=>import(`./ManageCareers-BpnVycS4.js`),__vite__mapDeps([91,1,2,3,4]))),mn=j.lazy(()=>C(()=>import(`./ManageLegal-B2RWdFQJ.js`),__vite__mapDeps([92,1,2,3,4,39,13]))),hn=j.lazy(()=>C(()=>import(`./ManageExitIntent-D4SVAmkV.js`),__vite__mapDeps([93,1,2,3,4]))),gn=j.lazy(()=>C(()=>import(`./ManageSocialProof-Cu4S1Hqy.js`),__vite__mapDeps([94,1,2,3,4]))),_n=j.lazy(()=>C(()=>import(`./ManageQuickConnect-DQpkbJ0G.js`),__vite__mapDeps([95,1,2,3,4]))),vn=j.lazy(()=>C(()=>import(`./ManageTestimonials-CPNALGw2.js`),__vite__mapDeps([96,1,2,3,4,39,13,15,6,7,59,60]))),yn=j.lazy(()=>C(()=>import(`./ManageNewsletter-BOeqLFuw.js`),__vite__mapDeps([97,1,2,3,4,6,7,59,13]))),bn=j.lazy(()=>C(()=>import(`./CMSLayout-BwGkuzI3.js`).then(e=>({default:e.CMSLayout})),__vite__mapDeps([98,1,2,3,4]))),xn=j.lazy(()=>C(()=>import(`./PageEditor-M4m9QJYe.js`).then(e=>({default:e.PageEditor})),__vite__mapDeps([99,1,2,3,4]))),Sn=j.lazy(()=>C(()=>import(`./AnalyticsDashboard-SQHsjvRh.js`),__vite__mapDeps([100,1,2,3,4,57,6,7]))),X=j.lazy(()=>C(()=>import(`./FacultyAnalytics-CIXj5573.js`),__vite__mapDeps([101,1,2,3,4,57,6,7]))),Cn=j.lazy(()=>C(()=>import(`./ManagementAnalytics-BewjT71F.js`),__vite__mapDeps([102,1,2,3,4,57,6,7]))),Z=j.lazy(()=>C(()=>import(`./AuditLogConsole-CVv08mLk.js`),__vite__mapDeps([103,1,2,3,4]))),wn=j.lazy(()=>C(()=>import(`./ManageMediaLibrary-CMlUsHCu.js`),__vite__mapDeps([104,1,2,3,4,6,7,12,13,60]))),Q=j.lazy(()=>C(()=>import(`./ManageCMSPages-DWC7mOFZ.js`),__vite__mapDeps([105,1,2,3,4,6,7,12,13,60]))),Tn=j.lazy(()=>C(()=>import(`./ManageRolesPermissions-_4FO60L8.js`),__vite__mapDeps([106,1,2,3,4,6,7,12,13,60]))),En=j.lazy(()=>C(()=>import(`./ManageLeadsCRM-DTOeAqq3.js`),__vite__mapDeps([107,1,2,3,4,6,7,12,13,59,60]))),Dn=j.lazy(()=>C(()=>import(`./ManageEmailCampaigns-DYHqFpAg.js`),__vite__mapDeps([108,1,2,3,4,6,7,12,13,59,60]))),On=j.lazy(()=>C(()=>import(`./ManageBackups-C0ihYw5N.js`),__vite__mapDeps([109,1,2,3,4,6,7]))),kn=()=>(0,M.jsxs)(`div`,{className:`min-h-screen flex flex-col font-sans selection:bg-primary-200 relative`,children:[(0,M.jsx)(mt,{opacity:.35}),(0,M.jsx)(Ze,{}),(0,M.jsxs)(`main`,{className:`flex-grow pt-[72px]`,children:[(0,M.jsx)(nt,{}),(0,M.jsx)(j.Suspense,{fallback:(0,M.jsx)(V,{}),children:(0,M.jsx)(ye,{})})]}),(0,M.jsx)(et,{}),(0,M.jsx)(rt,{}),(0,M.jsx)(it,{})]});function An(){return at(),ct(),(0,M.jsxs)(M.Fragment,{children:[(0,M.jsx)(B,{title:`Welcome`,description:`Tejas Academy of Excellence is a premier institution for modern education, providing world-class programs.`}),(0,M.jsx)(tt,{}),(0,M.jsxs)(se,{children:[(0,M.jsxs)(T,{path:`/admin`,element:(0,M.jsx)(R,{allowedRoles:[`admin`,`super_admin`],children:(0,M.jsx)(j.Suspense,{fallback:(0,M.jsx)(V,{}),children:(0,M.jsx)(Gt,{})})}),children:[(0,M.jsx)(T,{index:!0,element:(0,M.jsx)(Kt,{})}),(0,M.jsx)(T,{path:`analytics`,element:(0,M.jsx)(Sn,{})}),(0,M.jsx)(T,{path:`analytics/faculty`,element:(0,M.jsx)(X,{})}),(0,M.jsx)(T,{path:`analytics/management`,element:(0,M.jsx)(Cn,{})}),(0,M.jsx)(T,{path:`audit-logs`,element:(0,M.jsx)(Z,{})}),(0,M.jsxs)(T,{path:`cms`,element:(0,M.jsx)(bn,{}),children:[(0,M.jsx)(T,{index:!0,element:(0,M.jsx)(Q,{})}),(0,M.jsx)(T,{path:`pages`,element:(0,M.jsx)(Q,{})}),(0,M.jsx)(T,{path:`pages/:slug`,element:(0,M.jsx)(xn,{})}),(0,M.jsx)(T,{path:`settings`,element:(0,M.jsx)(Y,{})}),(0,M.jsx)(T,{path:`media`,element:(0,M.jsx)(wn,{})}),(0,M.jsx)(T,{path:`history`,element:(0,M.jsx)(Z,{})})]}),(0,M.jsx)(T,{path:`roles`,element:(0,M.jsx)(Tn,{})}),(0,M.jsx)(T,{path:`leads`,element:(0,M.jsx)(En,{})}),(0,M.jsx)(T,{path:`campaigns`,element:(0,M.jsx)(Dn,{})}),(0,M.jsx)(T,{path:`backups`,element:(0,M.jsx)(On,{})}),(0,M.jsx)(T,{path:`students`,element:(0,M.jsx)(qt,{})}),(0,M.jsx)(T,{path:`students/:id`,element:(0,M.jsx)(Jt,{})}),(0,M.jsx)(T,{path:`admissions`,element:(0,M.jsx)(Yt,{})}),(0,M.jsx)(T,{path:`admissions/:id`,element:(0,M.jsx)(Xt,{})}),(0,M.jsx)(T,{path:`inquiries`,element:(0,M.jsx)(Zt,{})}),(0,M.jsx)(T,{path:`programs`,element:(0,M.jsx)(Qt,{})}),(0,M.jsx)(T,{path:`programs/new`,element:(0,M.jsx)(U,{})}),(0,M.jsx)(T,{path:`programs/:id/edit`,element:(0,M.jsx)(U,{})}),(0,M.jsx)(T,{path:`mentors`,element:(0,M.jsx)($t,{})}),(0,M.jsx)(T,{path:`mentors/new`,element:(0,M.jsx)(W,{})}),(0,M.jsx)(T,{path:`mentors/:id/edit`,element:(0,M.jsx)(W,{})}),(0,M.jsx)(T,{path:`courses`,element:(0,M.jsx)(nn,{})}),(0,M.jsx)(T,{path:`courses/new`,element:(0,M.jsx)(q,{})}),(0,M.jsx)(T,{path:`courses/:id/edit`,element:(0,M.jsx)(q,{})}),(0,M.jsx)(T,{path:`events`,element:(0,M.jsx)(en,{})}),(0,M.jsx)(T,{path:`events/new`,element:(0,M.jsx)(G,{})}),(0,M.jsx)(T,{path:`events/:id/edit`,element:(0,M.jsx)(G,{})}),(0,M.jsx)(T,{path:`workshops`,element:(0,M.jsx)(tn,{})}),(0,M.jsx)(T,{path:`workshops/new`,element:(0,M.jsx)(K,{})}),(0,M.jsx)(T,{path:`workshops/:id/edit`,element:(0,M.jsx)(K,{})}),(0,M.jsx)(T,{path:`insights`,element:(0,M.jsx)(rn,{})}),(0,M.jsx)(T,{path:`insights/new`,element:(0,M.jsx)(J,{})}),(0,M.jsx)(T,{path:`insights/:id/edit`,element:(0,M.jsx)(J,{})}),(0,M.jsx)(T,{path:`gallery`,element:(0,M.jsx)(an,{})}),(0,M.jsx)(T,{path:`testimonials`,element:(0,M.jsx)(vn,{})}),(0,M.jsx)(T,{path:`newsletter`,element:(0,M.jsx)(yn,{})}),(0,M.jsx)(T,{path:`cms/homepage`,element:(0,M.jsx)(on,{})}),(0,M.jsx)(T,{path:`cms/about`,element:(0,M.jsx)(sn,{})}),(0,M.jsx)(T,{path:`cms/campus`,element:(0,M.jsx)(fn,{})}),(0,M.jsx)(T,{path:`cms/careers`,element:(0,M.jsx)(pn,{})}),(0,M.jsx)(T,{path:`cms/legal`,element:(0,M.jsx)(mn,{})}),(0,M.jsx)(T,{path:`cms/seo`,element:(0,M.jsx)(cn,{})}),(0,M.jsx)(T,{path:`cms/settings`,element:(0,M.jsx)(Y,{})}),(0,M.jsx)(T,{path:`cms/notifications`,element:(0,M.jsx)(ln,{})}),(0,M.jsx)(T,{path:`cms/faq`,element:(0,M.jsx)(un,{})}),(0,M.jsx)(T,{path:`cms/navigation`,element:(0,M.jsx)(dn,{})}),(0,M.jsx)(T,{path:`cms/exit-intent`,element:(0,M.jsx)(hn,{})}),(0,M.jsx)(T,{path:`cms/social-proof`,element:(0,M.jsx)(gn,{})}),(0,M.jsx)(T,{path:`cms/quick-connect`,element:(0,M.jsx)(_n,{})})]}),(0,M.jsxs)(T,{element:(0,M.jsx)(kn,{}),children:[(0,M.jsx)(T,{path:`/login`,element:(0,M.jsx)(Bt,{})}),(0,M.jsx)(T,{path:`/register`,element:(0,M.jsx)(Vt,{})}),(0,M.jsx)(T,{path:`/forgot-password`,element:(0,M.jsx)(Ht,{})}),(0,M.jsx)(T,{path:`/reset-password`,element:(0,M.jsx)(H,{})}),(0,M.jsx)(T,{path:`/reset-password/:token`,element:(0,M.jsx)(H,{})}),(0,M.jsx)(T,{path:`/dashboard`,element:(0,M.jsx)(R,{children:(0,M.jsx)(Ut,{})})}),(0,M.jsx)(T,{path:`/faculty`,element:(0,M.jsx)(R,{allowedRoles:[`faculty`,`admin`,`super_admin`],children:(0,M.jsx)(Wt,{})})}),(0,M.jsx)(T,{path:`/`,element:(0,M.jsx)(ht,{})}),(0,M.jsx)(T,{path:`/about`,element:(0,M.jsx)(gt,{})}),(0,M.jsx)(T,{path:`/about/vision-mission`,element:(0,M.jsx)(_t,{})}),(0,M.jsx)(T,{path:`/about/campus`,element:(0,M.jsx)(vt,{})}),(0,M.jsx)(T,{path:`/programs`,element:(0,M.jsx)(yt,{})}),(0,M.jsx)(T,{path:`/programs/:slug`,element:(0,M.jsx)(bt,{})}),(0,M.jsx)(T,{path:`/free-programs`,element:(0,M.jsx)(At,{})}),(0,M.jsx)(T,{path:`/for-institutions`,element:(0,M.jsx)(jt,{})}),(0,M.jsx)(T,{path:`/recognitions`,element:(0,M.jsx)(Mt,{})}),(0,M.jsx)(T,{path:`/admissions`,element:(0,M.jsx)(xt,{})}),(0,M.jsx)(T,{path:`/join-us`,element:(0,M.jsx)(zt,{})}),(0,M.jsx)(T,{path:`/mentors`,element:(0,M.jsx)(St,{})}),(0,M.jsx)(T,{path:`/events`,element:(0,M.jsx)(Ct,{})}),(0,M.jsx)(T,{path:`/gallery`,element:(0,M.jsx)(wt,{})}),(0,M.jsx)(T,{path:`/insights`,element:(0,M.jsx)(Tt,{})}),(0,M.jsx)(T,{path:`/insights/:slug`,element:(0,M.jsx)(Et,{})}),(0,M.jsx)(T,{path:`/resources`,element:(0,M.jsx)(Dt,{})}),(0,M.jsx)(T,{path:`/placements`,element:(0,M.jsx)(Ot,{})}),(0,M.jsx)(T,{path:`/testimonials`,element:(0,M.jsx)(kt,{})}),(0,M.jsx)(T,{path:`/contact`,element:(0,M.jsx)(Nt,{})}),(0,M.jsx)(T,{path:`/career`,element:(0,M.jsx)(Pt,{})}),(0,M.jsx)(T,{path:`/support`,element:(0,M.jsx)(Ft,{})}),(0,M.jsx)(T,{path:`/privacy`,element:(0,M.jsx)(It,{})}),(0,M.jsx)(T,{path:`/terms`,element:(0,M.jsx)(Lt,{})}),(0,M.jsx)(T,{path:`*`,element:(0,M.jsx)(Rt,{})})]})]})]})}var $=(0,j.createContext)(),jn=()=>(0,j.useContext)($),Mn=({children:e})=>{let[t,n]=(0,j.useState)(null),{user:r}=k(),i=ge();return(0,j.useEffect)(()=>{if(!r){t&&(t.disconnect(),n(null));return}let e=f(`https://unlocktejas.com`,{withCredentials:!0,transports:[`websocket`]});return n(e),e.on(`connect`,()=>{r.role===`admin`||r.role===`super_admin`||r.role===`operations_manager`?e.emit(`join_admin_room`):e.emit(`join_user_room`,r.id||r._id)}),e.on(`notification`,e=>{e.type===`success`?o.success(e.message,{title:e.title}):e.type===`error`?o.error(e.message,{title:e.title}):o(e.message,{title:e.title}),i.invalidateQueries()}),e.on(`admin_notification`,e=>{o.info(e.message,{title:`Admin Alert: ${e.title}`,icon:`🔔`}),i.invalidateQueries()}),e.on(`ADMIN_ANALYTICS_UPDATED`,e=>{i.invalidateQueries([`admin-analytics`])}),()=>{e.disconnect()}},[r]),(0,M.jsx)($.Provider,{value:{socket:t},children:e})},Nn=(0,j.createContext)({theme:{primaryColor:`#0f172a`,secondaryColor:`#d97706`,accentColor:`#f59e0b`,borderRadius:`0.75rem`,fontFamily:`Inter, sans-serif`}}),Pn=({children:e})=>{let{data:t}=b({queryKey:[`sanity`,`theme_settings`],queryFn:()=>P.getThemeSettings(),staleTime:300*1e3}),n=t||{primaryColor:`#0f172a`,secondaryColor:`#d97706`,accentColor:`#f59e0b`,borderRadius:`0.75rem`,fontFamily:`Inter, sans-serif`};return(0,j.useEffect)(()=>{if(n){let e=document.documentElement;n.primaryColor&&e.style.setProperty(`--color-primary-custom`,n.primaryColor),n.secondaryColor&&e.style.setProperty(`--color-secondary-custom`,n.secondaryColor),n.accentColor&&e.style.setProperty(`--color-accent-custom`,n.accentColor),n.borderRadius&&e.style.setProperty(`--radius-custom`,n.borderRadius)}},[n]),(0,M.jsx)(Nn.Provider,{value:{theme:n},children:e})},Fn=new a;Ce.createRoot(document.getElementById(`root`)).render((0,M.jsx)(j.StrictMode,{children:(0,M.jsx)(ve,{children:(0,M.jsx)(ue,{children:(0,M.jsxs)(_e,{client:Fn,children:[(0,M.jsx)(we,{children:(0,M.jsx)(Mn,{children:(0,M.jsx)(Pn,{children:(0,M.jsx)(An,{})})})}),(0,M.jsx)(t,{position:`top-right`,richColors:!0})]})})})}));export{F as a,I as i,B as n,P as o,L as r,N as s,jn as t};