import { v2 as cloudinary } from 'cloudinary';

export const configureCloudinary = () => {
  if (!process.env.CLOUDINARY_CLOUD_NAME || process.env.CLOUDINARY_CLOUD_NAME === 'your_cloudinary_cloud_name') {
    console.warn('[!] Cloudinary is not configured in .env. Image uploads will fail.');
    return;
  }
  
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  console.log('[+] Cloudinary configured successfully.');
};
